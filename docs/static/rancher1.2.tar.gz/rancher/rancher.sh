#!/bin/bash
mv /opt/rackshift/rackhd/files/mount/common/vmlinuz-1.2.0-rancher /opt/rackshift/rackhd/files/mount/common/vmlinuz-1.5.6-rancher
mv /opt/rackshift/rackhd/files/mount/common/initrd-1.2.0-rancher /opt/rackshift/rackhd/files/mount/common/initrd-1.5.6-rancher
cp ./vmlinuz /opt/rackshift/rackhd/files/mount/common/vmlinuz-1.2.0-rancher
cp ./initrd /opt/rackshift/rackhd/files/mount/common/initrd-1.2.0-rancher
echo success change rancher to 1.2.0
